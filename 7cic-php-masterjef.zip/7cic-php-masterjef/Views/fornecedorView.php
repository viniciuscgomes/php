<?php 
	
	require_once '../DAO/ConexaoDAO.php';
	require_once '../DAO/FornecedoresDAO.php';

	$forneDAO = new FornecedoresDAO();

	$fornecedores = $forneDAO->listarFornecedores();

	?>

	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.min.css">

	<div class="container">
		<hr>

		<table class="table table-bordered" border=1>
			<thead>
				<tr>
					<th>CompanyName</th>
					<th>ContactName</th>
					<th>Address</th>
					<th>City</th>
					<th>Phone</th>
				</tr>
			</thead>
			<tbody><!--foreach(array as nova variavel) -->
				<?php foreach($fornecedores as $fornecedor): ?>
					<tr>
						<td><?php echo $fornecedor->getCompanyName(); ?></td>
						<td><?php echo $fornecedor->getContactName(); ?></td>
						<td><?php echo $fornecedor->getAddress(); ?></td>
						<td><?php echo $fornecedor->getCity(); ?></td>
						<td><?php echo $fornecedor->getPhone(); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>

	<?php
	
 ?>